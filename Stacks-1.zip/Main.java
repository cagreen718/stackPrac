import java.util.Stack;

 public class Main {
  public static void main(String[] args) {


		Stack<String>vidGam=new Stack<String>();


		vidGam.push("MY");
		vidGam.push("poop");
		vidGam.push("is");
		vidGam.push("runny");

		System.out.println(vidGam);
  }
}